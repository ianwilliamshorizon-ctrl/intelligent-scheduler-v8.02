
import React from 'react';
import { EstimateLineItem, TaxRate, Part, PurchaseOrder, ServicePackage } from '../../../types';
import { Trash2, PlusCircle } from 'lucide-react';
import { formatCurrency } from '../../../utils/formatUtils';
import SearchableSelect from '../../SearchableSelect';

// Reusable Row Component within the tab
interface EditableLineItemRowProps {
    item: EstimateLineItem;
    taxRates: TaxRate[];
    filteredParts: Part[];
    activePartSearch: string | null;
    onLineItemChange: (id: string, field: keyof EstimateLineItem, value: any) => void;
    onRemoveLineItem: (id: string) => void;
    onPartSearchChange: (value: string) => void;
    onSetActivePartSearch: (id: string | null) => void;
    onSelectPart: (lineItemId: string, part: Part) => void;
    isReadOnly: boolean;
    canViewPricing: boolean;
}

const MemoizedEditableLineItemRow = React.memo(({ item, taxRates, onLineItemChange, onRemoveLineItem, filteredParts, activePartSearch, onPartSearchChange, onSetActivePartSearch, onSelectPart, isReadOnly, canViewPricing }: EditableLineItemRowProps) => {
    const isPackageComponent = item.isPackageComponent;
    const isPackageHeader = !!item.servicePackageId && !item.isPackageComponent;

    const handleDescriptionChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        onLineItemChange(item.id, 'description', value);
        if (!item.isLabor && !isPackageHeader && !isPackageComponent) {
            onPartSearchChange(value);
        }
    };

    return (
         <div className={`grid grid-cols-12 gap-2 items-center p-2 rounded-lg border ${isPackageComponent ? 'bg-gray-100' : 'bg-white'}`}>
            <input type="text" placeholder="Part Number" value={item.partNumber || ''} onChange={e => onLineItemChange(item.id, 'partNumber', e.target.value)} className="col-span-2 p-1 border rounded disabled:bg-gray-200" disabled={isReadOnly || isPackageHeader || isPackageComponent || item.isLabor} />
            <div className="col-span-5 relative">
                 <input
                    type="text"
                    placeholder="Description"
                    value={item.description}
                    onChange={handleDescriptionChange}
                    onFocus={() => !item.isLabor && !isPackageHeader && !isPackageComponent && onSetActivePartSearch(item.id)}
                    onBlur={() => setTimeout(() => onSetActivePartSearch(null), 150)}
                    className="w-full p-1 border rounded disabled:bg-gray-200"
                    disabled={isReadOnly || isPackageHeader || isPackageComponent}
                />
                 {activePartSearch === item.id && filteredParts.length > 0 && (
                    <div className="absolute z-20 top-full left-0 w-full bg-white border rounded shadow-lg max-h-40 overflow-y-auto mt-1">
                        {filteredParts.map(part => (
                            <div key={part.id} onMouseDown={() => onSelectPart(item.id, part)} className="p-2 hover:bg-indigo-100 cursor-pointer text-sm">
                                <p className="font-semibold">{part.partNumber} - {part.description}</p>
                            </div>
                        ))}
                    </div>
                )}
            </div>
            <input type="number" step="0.1" value={item.quantity} onChange={e => onLineItemChange(item.id, 'quantity', e.target.value)} className="col-span-1 p-1 border rounded text-right disabled:bg-gray-200" disabled={isReadOnly || isPackageHeader} />
            {canViewPricing ? (
                <input type="number" step="0.01" value={item.unitPrice} onChange={e => onLineItemChange(item.id, 'unitPrice', e.target.value)} className="col-span-2 p-1 border rounded text-right disabled:bg-gray-200" placeholder="Sale (Net)" disabled={isReadOnly || isPackageHeader || isPackageComponent}/>
            ) : (
                <div className="col-span-2 p-1 text-right font-semibold text-gray-500">Hidden</div>
            )}
            <select value={item.taxCodeId || ''} onChange={e => onLineItemChange(item.id, 'taxCodeId', e.target.value)} className="col-span-1 p-1 border rounded text-xs disabled:bg-gray-200" disabled={isReadOnly || isPackageHeader}>
                <option value="">-- Tax --</option>{taxRates.map(t => <option key={t.id} value={t.id}>{t.code}</option>)}
            </select>
            <button onClick={() => onRemoveLineItem(item.id)} className="col-span-1 text-red-500 hover:text-red-700 justify-self-center disabled:opacity-50" disabled={isReadOnly || isPackageComponent}><Trash2 size={14} /></button>
        </div>
    );
});

interface JobEstimateTabProps {
    partsStatus: string;
    purchaseOrderIds: string[];
    purchaseOrders: PurchaseOrder[];
    supplierMap: Map<string, string>;
    editableEstimate: any; // Using explicit type locally would be better but keeping simple for refactor
    estimateBreakdown: { packages: any[], standaloneLabor: any[], standaloneParts: any[] };
    isReadOnly: boolean;
    canViewPricing: boolean;
    taxRates: TaxRate[];
    filteredParts: Part[];
    activePartSearch: string | null;
    servicePackages: ServicePackage[];
    totalNet: number;
    vatBreakdown: any[];
    grandTotal: number;
    onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
    onOpenPurchaseOrder: (po: PurchaseOrder) => void;
    onCreateEstimate: () => void;
    onAddLineItem: (isLabor: boolean) => void;
    onAddPackage: (packageId: string) => void;
    onLineItemChange: (id: string, field: keyof EstimateLineItem, value: any) => void;
    onRemoveLineItem: (id: string) => void;
    onPartSearchChange: (value: string) => void;
    onSetActivePartSearch: (id: string | null) => void;
    onSelectPart: (lineItemId: string, part: Part) => void;
}

export const JobEstimateTab: React.FC<JobEstimateTabProps> = ({
    partsStatus, purchaseOrderIds, purchaseOrders, supplierMap, editableEstimate,
    estimateBreakdown, isReadOnly, canViewPricing, taxRates, filteredParts, activePartSearch, servicePackages,
    totalNet, vatBreakdown, grandTotal, onChange, onOpenPurchaseOrder, onCreateEstimate,
    onAddLineItem, onAddPackage, onLineItemChange, onRemoveLineItem, onPartSearchChange, onSetActivePartSearch, onSelectPart
}) => {
    return (
        <div className="space-y-4 text-sm">
            <div>
                <label className="font-semibold">Parts Status</label>
                <select name="partsStatus" value={partsStatus || 'Not Required'} onChange={onChange} className="w-full p-2 border rounded bg-white mt-1" disabled={isReadOnly}>
                    <option>Not Required</option>
                    <option>Awaiting Order</option>
                    <option>Ordered</option>
                    <option>Partially Received</option>
                    <option>Fully Received</option>
                </select>
            </div>
            
            <div>
                <h4 className="font-semibold mb-2">Items</h4>
                {!editableEstimate && !isReadOnly && <button onClick={onCreateEstimate} className="text-indigo-600 hover:underline">This job has no estimate. Click here to add items.</button>}
                
                {editableEstimate && (
                    <div className="space-y-4">
                        {!isReadOnly && (
                            <div className="flex justify-between items-center pt-2">
                                <div className="flex gap-2">
                                    <button onClick={() => onAddLineItem(true)} className="flex items-center text-xs py-1 px-2 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200"><PlusCircle size={14} className="mr-1" /> Add Labor</button>
                                    <button onClick={() => onAddLineItem(false)} className="flex items-center text-xs py-1 px-2 bg-green-100 text-green-700 rounded-md hover:bg-green-200"><PlusCircle size={14} className="mr-1" /> Add Part</button>
                                </div>
                                <div className="flex items-center gap-2">
                                    <SearchableSelect
                                        options={servicePackages.map(p => ({ id: p.id, label: p.name }))}
                                        value={null} onChange={(packageId) => { if (packageId) onAddPackage(packageId); }}
                                        placeholder="-- Add Package --"
                                    />
                                </div>
                            </div>
                        )}
                        <div className="hidden lg:grid grid-cols-12 gap-2 text-xs text-gray-500 font-medium px-2">
                            <div className="col-span-2">Part No.</div><div className="col-span-5">Description</div>
                            <div className="col-span-1 text-right">Qty/Hrs</div>
                            {canViewPricing ? (
                                <div className="col-span-2 text-right">Sell Price (Net)</div>
                            ) : (
                                <div className="col-span-2"></div>
                            )}
                            <div className="col-span-1 text-center">Tax</div><div className="col-span-1"></div>
                        </div>
                        
                        {estimateBreakdown.packages.length > 0 && <h5 className="font-bold text-gray-800 text-xs uppercase pt-2">Service Packages</h5>}
                        {estimateBreakdown.packages.map(({ header, children }: any) => (<div key={header.id}><MemoizedEditableLineItemRow canViewPricing={canViewPricing} isReadOnly={isReadOnly} item={header} taxRates={taxRates} onLineItemChange={onLineItemChange} onRemoveLineItem={onRemoveLineItem} filteredParts={[]} activePartSearch={null} onPartSearchChange={()=>{}} onSetActivePartSearch={()=>{}} onSelectPart={()=>{}} /><div className="pl-6 border-l-2 ml-2 space-y-1 mt-1">{children.map((child: any) => (<MemoizedEditableLineItemRow key={child.id} canViewPricing={canViewPricing} isReadOnly={isReadOnly} item={child} taxRates={taxRates} onLineItemChange={onLineItemChange} onRemoveLineItem={onRemoveLineItem} filteredParts={[]} activePartSearch={null} onPartSearchChange={()=>{}} onSetActivePartSearch={()=>{}} onSelectPart={()=>{}} />))}</div></div>))}
                        
                        {estimateBreakdown.standaloneLabor.length > 0 && <h5 className="font-bold text-gray-800 text-xs uppercase pt-2">Standalone Labor</h5>}
                        {estimateBreakdown.standaloneLabor.map((item: any) => <MemoizedEditableLineItemRow key={item.id} canViewPricing={canViewPricing} isReadOnly={isReadOnly} item={item} taxRates={taxRates} onLineItemChange={onLineItemChange} onRemoveLineItem={onRemoveLineItem} filteredParts={filteredParts} activePartSearch={activePartSearch} onPartSearchChange={onPartSearchChange} onSetActivePartSearch={onSetActivePartSearch} onSelectPart={onSelectPart} />)}
                        
                        {estimateBreakdown.standaloneParts.length > 0 && <h5 className="font-bold text-gray-800 text-xs uppercase pt-2">Standalone Parts</h5>}
                        {estimateBreakdown.standaloneParts.map((item: any) => <MemoizedEditableLineItemRow key={item.id} canViewPricing={canViewPricing} isReadOnly={isReadOnly} item={item} taxRates={taxRates} onLineItemChange={onLineItemChange} onRemoveLineItem={onRemoveLineItem} filteredParts={filteredParts} activePartSearch={activePartSearch} onPartSearchChange={onPartSearchChange} onSetActivePartSearch={onSetActivePartSearch} onSelectPart={onSelectPart} />)}
                        
                        {canViewPricing && (
                            <div className="mt-4 pt-4 border-t flex justify-end">
                                <div className="w-64 text-sm">
                                    <div className="flex justify-between"><span>Net Total</span><span className="font-semibold">{formatCurrency(totalNet)}</span></div>
                                    {vatBreakdown.map(b => (<div key={b.name} className="flex justify-between text-gray-600"><span>VAT @ {b.rate}%</span><span>{formatCurrency(b.vat)}</span></div>))}
                                    <div className="flex justify-between font-bold text-lg mt-2 pt-2 border-t"><span>Grand Total</span><span>{formatCurrency(grandTotal)}</span></div>
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>

            <div>
                <h4 className="font-semibold">Linked Purchase Orders</h4>
                <div className="space-y-2 mt-1">
                    {(purchaseOrderIds || []).length > 0 ? (purchaseOrderIds || []).map(poId => {
                        const po = purchaseOrders.find(p => p.id === poId);
                        if (!po) return <div key={poId} className="p-2 border rounded-md bg-red-50 text-xs text-red-700">Error: Purchase Order {poId} not found.</div>;
                        const poTotal = (po.lineItems || []).reduce((sum, item) => sum + (item.unitPrice * item.quantity), 0);
                        return (
                            <button key={poId} type="button" onClick={() => onOpenPurchaseOrder(po)} className="w-full text-left border rounded-md bg-gray-50 text-xs hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                <div className="p-2 flex justify-between items-center">
                                    <div><p><strong>{poId}</strong> - {po?.supplierId ? (supplierMap.get(po.supplierId) || 'Unknown Supplier') : 'N/A'}</p><p>Status: <span className="font-semibold">{po.status}</span>{canViewPricing && <> - Total: <span className="font-semibold">{formatCurrency(poTotal)}</span></>} </p></div>
                                </div>
                            </button>
                        );
                    }) : <p className="text-xs text-gray-500">No purchase orders linked.</p>}
                </div>
            </div>
        </div>
    );
};
